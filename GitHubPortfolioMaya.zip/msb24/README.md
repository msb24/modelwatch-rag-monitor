# Hi, I'm Maya :)

**AI product & integration · RAG evaluation · responsible AI · technical prototyping**

I'm pursuing an **M.S. in Artificial Intelligence Management at Georgetown University (expected August 2027)**, based in Washington, DC. I work at the intersection of AI applications, product decisions, and the operational details that determine whether a system is useful, traceable, and safe to deploy.

My graduate portfolio spans **LLM/RAG evaluation, AI monitoring, healthcare system integration, document-processing rules, multimodal product discovery, and human-in-the-loop workflows**. I have hands-on experience with AI-assisted Python/Jupyter prototyping and turning ambiguous stakeholder requests into testable requirements.

### 🔎 Featured projects

| Project | What you can inspect | Scope |
| --- | --- | --- |
| [ModelWatch](https://github.com/msb24/modelwatch-rag-monitor) | Runnable Python notebook, synthetic monitoring dataset, **13 passing test scenarios**, incident logic, and dashboard | Academic prototype |
| [Document Decision Lab](https://github.com/msb24/document-decision-lab) | Document text parsing, policy-version checks, deterministic decision routing, tests, and an auditable CSV-to-JSON workflow | Independent synthetic demonstration |
| [Healthcare AI Integration](https://github.com/msb24/healthcare-ai-integration) | A systems map, integration-pattern tradeoffs, evidence controls, and a human-review architecture | Academic case-study design |
| [Aura Check](https://github.com/msb24/aura-check-authenticity) | Multimodal luxury-authenticity concept, proposed evidence schema, validation plan, and expert escalation | Product discovery / design concept |

### 🧠 What I'm working on

- **AI evaluation:** retrieval success, citation mismatch, user satisfaction, p95 latency, validation logic, incident review
- **Enterprise AI implementation:** RAG evidence flows, REST/FHIR integrations, ETL, middleware, audit trails, release criteria
- **Responsible product design:** policy provenance, privacy, human oversight, accountable ownership, and uncertainty communication
- **Prototyping and tooling:** Python (AI-assisted), Jupyter, Google Colab, Hugging Face Spaces, Figma, GitHub, Vercel/v0, Google AI Studio, NotebookLM

### ✨ My approach

I start with the decision a user needs to make and work backward to the evidence required. For ModelWatch, that meant checking the numerator and denominator behind each metric, making invalid data block an incident classification, and keeping the final decision with a human owner. I also document what a synthetic demo **cannot** establish so that a clean dashboard doesn't become an unsupported reliability claim.

### 🎓 Background

**Georgetown University** · M.S. Artificial Intelligence Management, expected Aug 2027  
**University of Maryland, College Park** · B.S. Neurobiology & Physiology · Integrated Life Sciences Honors College · Banneker/Key Scholar · Minor in Persian Studies

Interested in opportunities involving **AI product operations, GenAI implementation, RAG evaluation, solution delivery, AI governance, and technical program/project work**.

<sub>Portfolio projects are labeled according to their maturity. Academic designs and synthetic demonstrations are not presented as production deployments. AI-assisted coding is disclosed within relevant project repositories.</sub>
