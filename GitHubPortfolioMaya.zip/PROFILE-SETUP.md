# GitHub setup checklist for @msb24

## Update the account profile

Suggested display name: **Maya** (or leave the display name blank for more privacy)

Suggested 160-character bio:
`Georgetown MS AI Management | RAG Evaluation · AI Integration · Responsible AI | Python/Jupyter Prototypes | Washington, DC`

Suggested location: `Washington, DC`

## Upload in this order

1. Create a public repository named **modelwatch-rag-monitor**. Upload all files from its matching folder, maintaining directories and the `.ipynb` extension.
2. Create **document-decision-lab**. Upload its files. The demo uses Python's standard library and synthetic examples.
3. Create **healthcare-ai-integration**. Upload its README and `docs/` files. It is a design case study and includes no employer data.
4. Optionally create **aura-check-authenticity**. This is explicitly a product-discovery concept.
5. Create a public repository named **msb24** (exactly your GitHub username), and place `msb24/README.md` in the root. It will appear on your GitHub profile automatically.
6. On your GitHub profile choose **Customize your pins** and pin the most relevant three or four repositories.

GitHub profile README instructions: https://docs.github.com/en/account-and-profile/how-tos/profile-customization/managing-your-profile-readme

## Before publishing

- Remove or replace any file you are uncomfortable making public. All public GitHub content is accessible on the internet.
- Re-run the ModelWatch notebook and the document-decision tests from a clean session; check displayed results before upload.
- Add screenshots to the relevant repository as indicated in its README.
- Do not upload private data, course handouts, non-public workplace materials, API keys, or credentials.
- Do not claim that any prototype was deployed into a live clinical or enterprise environment.
- Review all AI-assisted artifacts and ensure each accurately reflects work you can explain in an interview.
- These files were packaged here; **nothing has been posted to GitHub automatically**.

## Recruiter-facing repository descriptions

`modelwatch-rag-monitor`: `Python/Jupyter RAG quality monitoring MVP | synthetic baseline-vs-current evaluation, 12 tests, incident triage, human review`

`document-decision-lab`: `Synthetic document-processing demo | structured extraction, policy version checks, auditable rule-based review routing`

`healthcare-ai-integration`: `Enterprise healthcare AI integration case study | EHR/FHIR, payer data intake, RAG provenance, audit and review`

`aura-check-authenticity`: `Multimodal luxury-authenticity product concept | evidence design, evaluation plan, and expert review`

Suggested topics:

- ModelWatch: `rag`, `llm-evaluation`, `python`, `jupyter-notebook`, `ai-observability`, `human-in-the-loop`
- Document Decision Lab: `document-processing`, `python`, `rule-engine`, `data-validation`, `audit-logging`
- Healthcare AI Integration: `healthcare-ai`, `system-design`, `fhir`, `rag`, `ai-governance`
- Aura Check: `multimodal-ai`, `product-management`, `computer-vision`, `responsible-ai`
