# Aura Check | Proposed evaluation plan

**Status:** A research plan for an unbuilt product. No dataset has been collected or results measured.

## Hypothesis

An evidence-first assistant can help pre-purchase buyers identify inconsistent listing information and determine when they need a qualified authenticator before spending money.

## Inputs that would need permission and validation

- Multiple angles of a bag's exterior and interior, including stitch lines, hardware, labels, and wear areas
- Listing claims about model, year, condition, provenance, and authenticity documents
- Seller-supplied provenance and marketplace metadata, subject to availability and lawful use
- An independently authenticated reference set and a counterfeits set whose labels have documented provenance

## Proposed evaluation sequence

1. **Data quality gate:** Inspect whether photographs are sufficient to support a reliable assessment. Flag missing viewpoints, blur, and inconsistent scales.
2. **Label audit:** Confirm that 'authentic' and 'counterfeit' reference labels originate from qualified inspection rather than seller self-report.
3. **Holdout split:** Separate near-duplicate listings and product families to reduce leakage from visually similar photographs.
4. **Calibration test:** Compare any displayed confidence against verified outcomes across price tiers and product families.
5. **False-reassurance analysis:** Examine instances where the assistant would encourage a purchase of an incorrectly labeled or unverifiable item.
6. **Expert escalation:** Ask specialists whether the evidence bundle provides enough information to justify their next review step.
7. **User experience:** Test whether uncertainty explanations change actual purchase behavior without creating excessive false alarms.

## Proposed output schema

```json
{
  "listing_id": "FICTIONAL-ITEM-01",
  "image_quality": "needs_more_photos",
  "supported_flags": ["serial-number-photo-missing"],
  "unverified_claims": ["seller_reports_original_receipt"],
  "authenticated": null,
  "recommended_next_step": "qualified_human_authentication"
}
```

A null value for `authenticated` is intentional. Photo-based evidence does not establish the product's authenticity on its own.

## Operational questions

The product cannot be responsibly launched until experts define label provenance, acceptable false reassurance, escalation capacity, source licensing, acceptable use, and how users can contest a mistake.
