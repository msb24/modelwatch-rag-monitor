# Aura Check | Luxury-Authenticity AI Product Discovery

**A multimodal concept for pre-purchase risk review of secondhand luxury handbags.**

**Status:** Product discovery and system design · Unbuilt concept · No trained authenticity classifier or commercial authentication service

## The problem

A buyer often sees seller photos, descriptions, prices, and limited provenance before making a high-stakes resale purchase. Some authenticity evidence requires physical inspection, making an image-only prediction vulnerable to false confidence.

## Proposed experience

```mermaid
flowchart LR
  A[Listing photos, text, seller metadata] --> B[Input quality and metadata checks]
  B --> C[Visual and textual evidence retrieval]
  C --> D[Cross-check provenance and inconsistent claims]
  D --> E[Evidence-supported risk review]
  E --> F{Evidence sufficient?}
  F -->|No| G[Escalate to qualified authentication]
  F -->|Potentially| H[Show limits and next checks]
```

### Proposed product rules

- Preserve which listing image or seller statement supports each flag.
- Separate **missing evidence** from **negative evidence**.
- Never present a listing-photo assessment as a guarantee of authenticity.
- Require specialized expert review for ambiguous or expensive purchases.
- Calibrate uncertainty and prioritize avoiding dangerous false reassurance.

### Initial evaluation plan

| Test | What it would answer |
| --- | --- |
| Image-quality stress cases | How do crop, lighting, compression, and angle affect signals? |
| Known authentic and known counterfeit reference sets | Can the system generalize beyond training artifacts? |
| Model confidence calibration | Does reported confidence track observed accuracy? |
| False reassurance review | How often are risky items presented as safe? |
| Human-expert agreement study | When does the tool meaningfully help an expert? |

## Product discovery context

This was compared against a video-retrieval concept and an AI quality-monitoring concept as part of a graduate portfolio exercise. The monitoring concept, ModelWatch, was selected for coding. Aura Check remains a documented product hypothesis, available for future validation and design work.

**Scope caveat:** No live dataset, device-level authentication, model weights, visual feature model, production accuracy claims, or end-user deployment are supplied.
