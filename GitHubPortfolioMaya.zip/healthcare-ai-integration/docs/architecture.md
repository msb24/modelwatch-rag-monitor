# Integration patterns and evidence contract

## Ingestion and normalization

1. **PDF files:** capture document ID, file hash, publication/effective/expiry dates, extraction confidence, version, field provenance, and approval status.
2. **CSV feeds:** validate column requirements, record counts, types, change dates, and missingness; reject unusable records to a review queue.
3. **Payer APIs:** record endpoint version, request/correlation ID, freshness, and source identity. Validate response schema before normalization.
4. **Evidence store:** publish only source-approved, currently effective criteria. If an import fails, preserve the previously approved record with an explicit freshness warning or hold new decisions, subject to clinical policy.
5. **Retrieval:** attach policy version and excerpt identifiers to the case-level evidence bundle; avoid patient-sensitive shared answer caches.

## Proposed case-level evidence record

```json
{
  "case_id": "SYNTH-CASE-001",
  "policy_id": "SYNTH-POL-17",
  "policy_version": "2026-Q3",
  "source_format": "pdf",
  "source_effective_date": "2026-07-01",
  "source_validated": true,
  "evidence_excerpt_id": "section-4-example",
  "retrieval_timestamp": "2026-10-01T00:00:00Z",
  "recommended_route": "HUMAN_REVIEW",
  "reviewer_decision": null
}
```

The record is illustrative. Actual implementations must add access control, clinical validation, source licensing, contractual requirements, and privacy safeguards.

## Integration contracts to verify

- EHR/FHIR scopes, rate limits, concurrency, writeback semantics, and failure recovery
- Documentation of the downstream authorization system's status fields and error responses
- Review queue owners, deadlines, identity/access rules, and who can overturn a suggested route
- Audit-store durability, retention and deletion duties, idempotency key, and replay checks
- Deployment-gate signoffs from security, compliance, architecture, clinical operations, and the vendor
