# Release-readiness questions

| Question | Proposed control | Evidence needed before any real deployment |
| --- | --- | --- |
| Is each policy current? | Effective-date gate and compliance approval | Versioned source acceptance log |
| Is each rule traceable? | Policy ID, excerpt ID, schema/version fields | Reviewer can reproduce rationale |
| Is PHI minimized? | Case-scoped retrieval and role-based access | Security/privacy signoff and tests |
| Is an invalid import contained? | Reject or quarantine source version | Failure-injection exercise |
| Do clinician escalations work? | Named review queue and operating SLA | End-to-end owner acceptance test |
| Are audit records durable? | Event persistence and idempotency | Broker/outage replay results |
| Can the system recover? | Documented rollback and reconciliation | Recovery drill preserving records |
| Is the deployment clinically safe? | Human accountability and staged pilot | Clinical validation and compliance approval |

The course project assesses design decisions. All checks listed here are **proposed release requirements**, not completed deployment validations.
