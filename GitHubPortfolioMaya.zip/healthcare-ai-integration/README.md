# Healthcare AI Integration | Prior Authorization Case Study

**Enterprise systems-design case study with policy ingestion, RAG evidence retrieval, human review, and auditable status routing.**

**Status:** Georgetown M.S. Artificial Intelligence Management academic scenario · Architecture/analysis only · No live clinical integration or patient data

## The decision problem

A prior-authorization support service has to reconcile clinical context with payer-specific criteria that arrive in different formats and on different schedules. The integration challenge extends beyond an LLM: source versions, latency, legacy systems, approvals, human review, and audit retention all influence whether a recommendation is usable.

```mermaid
flowchart TD
    A[EHR / FHIR adapter] --> B[Case orchestration]
    P1[Versioned PDF policy documents] --> X[Batch extract / normalize]
    P2[Scheduled CSV policy tables] --> X
    P3[Credentialed payer APIs] --> X
    X --> V[Effective-date and provenance validation]
    V --> DB[(Approved policy evidence store)]
    DB --> R[Grounded policy retrieval]
    R --> B
    B --> G{Evidence complete and current?}
    G -->|Yes| H[Prepared rationale for clinical review]
    G -->|No| I[Escalation / human review]
    H --> I
    I --> S[Authorized reviewer records outcome]
    S --> W[EHR and authorization status interfaces]
    B --> O[Durable decision and audit events]
    O --> L[Compliance / audit store]
```

### Design choices

| Requirement | Proposed integration | Why |
| --- | --- | --- |
| Clinical record access | Request-response through an EHR/FHIR adapter | A case needs current record context and traceable identifiers |
| Payer PDF and CSV intake | Scheduled batch extraction and normalization | Criteria can be reviewed before cases rely on them |
| Payer API criteria | Credentialed REST access with schema validation | A single policy normalization stage avoids diverging intake rules |
| AI evidence lookup | Versioned policy store with scoped retrieval | Each recommendation needs an identifiable policy version |
| Human escalation | Explicit review queue and accountable owner | Missing or disputed evidence requires clinical review |
| Audit evidence | Durable event handoff and duplicate detection | An outage should not silently discard a decision history |
| Reporting | Scheduled aggregated exports | Avoid unnecessary patient identifiers and operational coupling |

## Critical failure cases

1. **Outdated criteria:** A PDF arrives with an expired effective date. Import is held pending compliance verification.
2. **Incomplete document extraction:** A required field is missing. The system flags missing evidence and routes the case to a reviewer.
3. **Legacy interface changes:** A status field changes in a downstream vendor API. An adapter contains the change and preserves auditability.
4. **Load and deadline conflict:** Clinical requests exceed safe capacity. The design requires realistic burst testing and documented fallback behavior.
5. **Unresolved ownership:** Audit retention, clinical decision authority, and reviewer routing need named responsible teams before release.

## Deliverables

- [Integration architecture and data-contract notes](docs/architecture.md)
- [Risks, controls, and release questions](docs/release-checklist.md)

**Boundaries:** A course scenario, not an operating health system. No real EHR connection, payer credentials, PHI, authorization decisions, or production service is included. Architecture patterns are proposals whose correctness must be confirmed with actual system owners and contracts.
