# ModelWatch | RAG Quality Monitoring MVP

**A tested, low-fidelity Python/Jupyter experiment for spotting changes in a Support RAG Assistant and preparing evidence for a human owner.**

**Project status:** Academic prototype · September 2026 · Synthetic telemetry · **13 automated behavioral cases**

![ModelWatch dashboard, generated from illustrative data](assets/modelwatch-dashboard.png)

## The product question

When customer satisfaction drops in an AI support assistant, can a product owner see **which measurable signals changed**, whether the data is trustworthy, and what to investigate next?

The interface is a decision aid for the human owner. It does not diagnose the root cause or autonomously alter a deployed model.

## A working end-to-end notebook

Open **[ModelWatch RAG Monitor.ipynb](./ModelWatch%20RAG%20Monitor.ipynb)** in Jupyter or [Google Colab](https://colab.research.google.com/), then run every cell from top to bottom. Requirements are in `requirements.txt`.

```mermaid
flowchart LR
    A[8 synthetic daily records] --> B[Schema and value validation]
    B -->|Valid| C[Four monitoring metrics]
    B -->|Invalid| X[Blocked / insufficient evidence]
    C --> D[Compare baseline vs current]
    D --> E[Threshold checks]
    E --> F[Incident severity and evidence]
    F --> G[Draft owner handoff]
    G --> H[Human investigation]
```

The notebook writes a reproducible `modelwatch_monitoring_data.csv` from in-memory synthetic records, calculates summary metrics, exercises the incident logic, runs the 13 test scenarios, and renders the dashboard.

## Example results from the controlled synthetic run

| Measure | Baseline | Current | Interpretation |
| --- | ---: | ---: | --- |
| CSAT, pooled positive ratings / rated conversations | 82.9% | 73.9% | Decrease |
| Retrieval success, pooled successful retrievals / attempts | 90.1% | 79.1% | Decrease |
| Citation mismatches / cited answers | 1.7% | 6.2% | Increase |
| Median of daily p95 latencies | 1.8 s | 1.8 s | Unchanged |

**Synthetic incident classification:** High, with three degraded quality measures triggering a proposed human review. The notebook's thresholds are exercise settings, not evidence-calibrated service-level objectives.

## What makes the metric math important

- **Pooled denominators:** Period-level CSAT and retrieval rates sum the raw counts before division. Averaging daily percentages can overrepresent low-volume days.
- **Citation mismatch rate:** Denominator is cited answers; measuring against all conversations would dilute the signal.
- **Latency labeling:** Eight *daily* p95 values cannot produce a true p95 across all underlying requests. The notebook reports their median and labels the statistic accordingly.
- **Validation-first logic:** Missing values, duplicate dates, impossible numerator/denominator pairs, and negative latency block incident classification.
- **Conservative causal interpretation:** A synthetic knowledge-base update is flagged as a possible contributor. Chronological proximity is not proof of causation.

## What is tested

Thirteen behavioral cases cover stable telemetry, isolated declines, combined declines, missing fields, missing values, duplicate dates, invalid denominators, impossible counts, slow latency, and improving latency. The notebook raises an assertion if any expected result fails.

## Limits and next evaluation

Eight fabricated daily observations can demonstrate correct branching and handoff design; they **cannot establish statistical drift**, estimate false alarm rates, or validate a production alert threshold. A next iteration would replay historical incidents, measure owner-review burden and miss rates, and evaluate retrieval/citation flags against human-labeled traces.

## Tools and development process

Python, pandas, NumPy, Matplotlib, Jupyter/Colab, Figma for earlier UX flows. Python development was AI-assisted, with iterative human inspection, code execution, correction of metric definitions, and tests. No proprietary telemetry, client data, or production service is included.
