# Document Decision Lab | Document Extraction + Rule-based Review Routing

**A small, runnable synthetic demonstration of text extraction, policy validation, deterministic review routing, and audit records.**

**Status:** Independent portfolio demo, October 2026 · Built with AI assistance · No production deployment or real patient documents

## Why this exists

A document-processing system must know which source evidence it used, whether the policy is currently valid, and when missing inputs require a human decision. This experiment makes that control path visible without exposing patient data or delegating clinical authorization to software.

## What the program does

1. Extracts typed key-value fields from **synthetic policy text documents**. It intentionally uses simple structured text instead of claiming OCR/PDF understanding.
2. Normalizes fields and checks policy effective dates and required documents.
3. Reads synthetic case intake records from a CSV.
4. Routes each case to **human review** with a reason code. No case is automatically authorized or denied.
5. Writes JSON Lines audit records with policy ID, source hash, and missing-document explanations.
6. Runs unit tests for parsing, malformed evidence, stale policy, missing documents, unknown policy, and successful review-ready routing.

```mermaid
flowchart LR
  A[Synthetic policy TXT] --> B[Extract & validate fields]
  C[Case CSV] --> D[Normalize records]
  B --> E[Date and evidence checks]
  D --> E
  E --> F[Review routing with reason codes]
  F --> G[JSONL audit file]
  G --> H[Human reviewer]
```

## Run in any Python 3.10+ environment

No extra packages are required.

```bash
python3 src/decision_lab.py --cases examples/cases.csv --policies examples/policies --as-of 2026-10-13 --output results/review-decisions.jsonl
python3 -m unittest discover -s tests -v
```

An example output record looks like:

```json
{
  "case_id": "DEMO-1001",
  "route": "REVIEW_READY",
  "reasons": ["POLICY_CURRENT", "DOCUMENTS_COMPLETE"],
  "policy_id": "POL-2026-A",
  "human_review_required": true
}
```

The actual output also includes `source_sha256` and the missing-document list. It contains no personal medical data.

## Review statuses

| Status | Meaning | Next step |
| --- | --- | --- |
| `REVIEW_READY` | Relevant valid policy and listed inputs are present | Human reviewer evaluates case |
| `MISSING_DOCUMENTS` | One or more source-defined required documents missing | Request missing inputs; human decides |
| `POLICY_INVALID` | Policy has expired or is not yet effective | Hold and confirm current policy |
| `NO_MATCHING_POLICY` | No valid matching payer/service entry | Manual policy lookup |
| `MALFORMED_POLICY` | Document extraction or policy fields are invalid | Repair or verify source |

## Engineering tradeoffs

- A simple `Key: Value` parser keeps extraction behavior inspectable. Real PDFs and scans would require separately tested parsing/OCR and layout handling.
- Validation runs *before* review routing. Records with incomplete policy metadata do not receive a review-ready status.
- Traceability uses a SHA-256 file digest and policy identifier; real deployment would also need signed provenance, access controls, retention, and a durable audit backend.
- A synthetic date-bound policy decision says only that **the available evidence is suitable for human evaluation**. It does not determine clinical eligibility.

## Next tests

Use real but properly authorized de-identified policy samples; measure field-level extraction precision/recall; add version-conflict cases, parser confidence/abstention, PDF and OCR paths, signed source ingestion, replay protection, and reviewer agreement. Those features are **proposed**, not included in this MVP.

### AI assistance disclosure

This demonstrator's code and documentation were produced with AI assistance from requirements informed by the author's graduate AI integration portfolio. Code was executed and tested in an isolated synthetic environment for publication as a learning artifact. It does not represent prior paid engineering experience.
