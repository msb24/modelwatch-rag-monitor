"""Synthetic policy-text extractor and human-review router.

Portfolio experiment only. This does not issue medical authorizations.
"""
from __future__ import annotations
import argparse
import csv
from datetime import date
import hashlib
import json
from pathlib import Path

REQUIRED_POLICY_FIELDS = ('policy_id', 'payer', 'service', 'effective_date', 'expires', 'required_documents')

class PolicyError(ValueError):
    pass

def parse_policy_text(text: str) -> dict:
    """Parse one field per line from a documented synthetic text format."""
    data = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        if ':' not in line:
            raise PolicyError(f'Unrecognized policy line: {line!r}')
        key, val = line.split(':', 1)
        key = key.strip().lower().replace(' ', '_')
        if key in data:
            raise PolicyError(f'Duplicate field: {key}')
        data[key] = val.strip()
    missing = [key for key in REQUIRED_POLICY_FIELDS if not data.get(key)]
    if missing:
        raise PolicyError('Missing required policy fields: ' + ', '.join(missing))
    try:
        effective = date.fromisoformat(data['effective_date'])
        expires = date.fromisoformat(data['expires'])
    except ValueError as exc:
        raise PolicyError('Policy dates must be ISO format YYYY-MM-DD') from exc
    if expires < effective:
        raise PolicyError('Policy expiry precedes effective date')
    docs = [x.strip().lower() for x in data['required_documents'].split(';') if x.strip()]
    if not docs:
        raise PolicyError('No required document names supplied')
    data['required_documents'] = docs
    data['effective_date'] = effective
    data['expires'] = expires
    return data

def load_policies(folder: Path) -> tuple[list[dict],list[dict]]:
    policies, errors = [], []
    for path in sorted(folder.glob('*.txt')):
        contents=path.read_bytes()
        digest=hashlib.sha256(contents).hexdigest()
        try:
            data=parse_policy_text(contents.decode('utf-8'))
            data['source_sha256']=digest
            data['source_file']=path.name
            policies.append(data)
        except (PolicyError,UnicodeDecodeError) as exc:
            errors.append({'source_file':path.name,'source_sha256':digest,'error':str(exc)})
    return policies,errors

def route_case(case: dict, policies: list[dict], as_of: date, policy_errors: list[dict]|None=None) -> dict:
    case_id=(case.get('case_id') or '').strip()
    payer=(case.get('payer') or '').strip().lower()
    service=(case.get('service') or '').strip().lower()
    if not case_id or not payer or not service:
        raise ValueError('Each case must include case_id, payer, and service')
    supplied={x.strip().lower() for x in (case.get('document_list') or '').split(';') if x.strip()}
    matched=[p for p in policies if p['payer'].lower()==payer and p['service'].lower()==service]
    base={'case_id':case_id,'route':None,'reasons':[],'policy_id':None,
          'source_sha256':None,'missing_documents':[],'human_review_required':True}
    if not matched:
        base.update(route='NO_MATCHING_POLICY',reasons=['NO_VALIDATED_POLICY_FOUND'])
        return base
    # If more than one policy matches, avoid choosing a convenient version silently.
    if len(matched)>1:
        base.update(route='POLICY_INVALID',reasons=['MULTIPLE_POLICY_VERSIONS_REQUIRE_REVIEW'])
        return base
    p=matched[0]
    base['policy_id']=p['policy_id']
    base['source_sha256']=p['source_sha256']
    if not (p['effective_date']<=as_of<=p['expires']):
        base.update(route='POLICY_INVALID',reasons=['POLICY_DATE_OUTSIDE_EFFECTIVE_WINDOW'])
        return base
    missing=sorted(set(p['required_documents'])-supplied)
    if missing:
        base.update(route='MISSING_DOCUMENTS',reasons=['REQUIRED_DOCUMENTS_MISSING'],missing_documents=missing)
        return base
    base.update(route='REVIEW_READY',reasons=['POLICY_CURRENT','DOCUMENTS_COMPLETE'])
    return base

def run(cases_path:Path, policies_folder:Path, as_of:date, output:Path) -> list[dict]:
    policies,errors=load_policies(policies_folder)
    with cases_path.open(newline='',encoding='utf-8') as stream:
        cases=list(csv.DictReader(stream))
    results=[route_case(c,policies,as_of,errors) for c in cases]
    for r in results:
        r['evaluation_date']=as_of.isoformat()
        r['policy_parse_errors']=errors if r['route']=='NO_MATCHING_POLICY' and errors else []
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('w',encoding='utf-8') as stream:
        for record in results:
            stream.write(json.dumps(record,sort_keys=True)+'\n')
    return results

def main():
    parser=argparse.ArgumentParser(description='Synthetic document decisions for human review')
    parser.add_argument('--cases',type=Path,required=True)
    parser.add_argument('--policies',type=Path,required=True)
    parser.add_argument('--as-of',type=date.fromisoformat,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    results=run(args.cases,args.policies,args.as_of,args.output)
    for record in results:
        print(f"{record['case_id']}: {record['route']} ({', '.join(record['reasons'])})")
    print(f'Wrote {len(results)} synthetic audit records to {args.output}')
if __name__=='__main__':
    main()
