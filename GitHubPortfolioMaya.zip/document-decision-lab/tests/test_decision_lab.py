import sys
import unittest
from pathlib import Path
from datetime import date
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
from decision_lab import parse_policy_text, PolicyError, route_case, load_policies

ROOT=Path(__file__).resolve().parents[1]
class DocumentDecisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.policies,_=load_policies(ROOT/'examples'/'policies')
    def example(self,**kwargs):
        c={'case_id':'DEMO-1','payer':'Demo Health Plan','service':'Outpatient imaging','document_list':'Referral letter;Clinical note'}
        c.update(kwargs)
        return c
    def test_ready_always_requires_human(self):
        d=route_case(self.example(),self.policies,date(2026,10,13))
        self.assertEqual(d['route'],'REVIEW_READY'); self.assertTrue(d['human_review_required'])
    def test_missing_documents(self):
        d=route_case(self.example(document_list='Referral letter'),self.policies,date(2026,10,13))
        self.assertEqual(d['route'],'MISSING_DOCUMENTS'); self.assertEqual(d['missing_documents'],['clinical note'])
    def test_expired_policy(self):
        d=route_case(self.example(payer='Example Payer B',service='Specialty visit'),self.policies,date(2026,10,13))
        self.assertEqual(d['route'],'POLICY_INVALID')
    def test_future_policy(self):
        d=route_case(self.example(),self.policies,date(2025,10,13))
        self.assertEqual(d['route'],'POLICY_INVALID')
    def test_unknown_policy(self):
        d=route_case(self.example(payer='missing'),self.policies,date(2026,10,13))
        self.assertEqual(d['route'],'NO_MATCHING_POLICY')
    def test_malformed_date(self):
        with self.assertRaises(PolicyError):parse_policy_text('Policy ID: x\nPayer: x\nService: y\nEffective date: broken\nExpires: 2026-12-31\nRequired documents: x')
    def test_duplicate_key(self):
        with self.assertRaises(PolicyError):parse_policy_text('Policy ID: x\nPolicy ID: y\n')
    def test_empty_case_identifier(self):
        with self.assertRaises(ValueError):route_case(self.example(case_id=''),self.policies,date(2026,10,13))
    def test_multiple_version_hold(self):
        duplicate=self.policies[0].copy();duplicate['policy_id']='OTHER'
        d=route_case(self.example(),self.policies+[duplicate],date(2026,10,13))
        self.assertEqual(d['route'],'POLICY_INVALID')
if __name__=='__main__':unittest.main()
